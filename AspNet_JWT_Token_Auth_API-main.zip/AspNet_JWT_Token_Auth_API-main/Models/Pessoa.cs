﻿namespace AulaRestAPI.Models
{
    public class Pessoa
    {
        public int id { get; set; }
        public string nome { get; set; }
    }
}
