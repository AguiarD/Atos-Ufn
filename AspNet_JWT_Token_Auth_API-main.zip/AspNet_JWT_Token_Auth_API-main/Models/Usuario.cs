﻿namespace AulaRestAPI.Models
{
    public class Usuario
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
