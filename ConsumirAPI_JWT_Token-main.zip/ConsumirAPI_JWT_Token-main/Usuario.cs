﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsumirAPI_JWT_Token
{
    public class Usuario
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
